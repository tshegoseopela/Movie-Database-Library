CREATE DATABASE MOVIE_DB_LIBRARY; --creating db
USE MOVIE_DB_LIBRARY; --using db

--creating user table
CREATE TABLE USERS
(
   userID INT NOT NULL,
   uName VARCHAR(20) NOT NULL,
   uSurname VARCHAR(20) NOT NULL,
   userName VARCHAR(10) NOT NULL,
   userPassword VARCHAR(10) NOT NULL,
   PRIMARY KEY(userID)
);

--creating movie table
CREATE TABLE MOVIES
(
   movieID INT NOT NULL,
   userID INT NOT NULL,
   movieName VARCHAR(20) NOT NULL,
   movieDirector VARCHAR(20) NOT NULL,
   movieGenre VARCHAR(20) NOT NULL,
   movieLength INT NOT NULL,
   PRIMARY KEY(movieID),
   FOREIGN KEY(userID) REFERENCES USERS(userID)
);

--populating the tables(users + movie)
INSERT INTO USERS(userID,uName,uSurname,userName,userPassword)
VALUES(1,'Tshegofatso','Seopela','tshegosops','win123');

INSERT INTO USERS(userID,uName,uSurname,userName,userPassword)
VALUES(2,'T','Sops','ttSops','win123');

INSERT INTO USERS(userID,uName,uSurname,userName,userPassword)
VALUES(3,'Tshego','S','tshegoSeo','abc123');

INSERT INTO MOVIES(movieID,userID,movieName,movieDirector,movieGenre,movieLength)
VALUES(1,1,'Interstellar','Chris Nolan','Sci-Fi',180);

INSERT INTO MOVIES(movieID,userID,movieName,movieDirector,movieGenre,movieLength)
VALUES(2,1,'Inception','Chris Nolan','Sci-Fi',120);

INSERT INTO MOVIES(movieID,userID,movieName,movieDirector,movieGenre,movieLength)
VALUES(3,2,'The Batman','IDK','Action',120);

--display the name/director/username/m-length for user id 1
SELECT movieName, movieDirector,users.userName,movieLength
FROM MOVIES
INNER JOIN USERS ON users.userID = movies.movieID
WHERE movies.movieID = 1;

--display all the users that have a chris nolan movie
SELECT users.userName, users.uName, users.uSurname
FROM MOVIES
INNER JOIN USERS ON users.userID = movies.movieID
WHERE movies.movieDirector = 'Chris Nolan'; 

SELECT movies.movieName, movies.movieDirector, movies.movieLength
FROM MOVIES
WHERE movieLength > 120;

SELECT * FROM MOVIES;
SELECT * FROM USERS;

SELECT * FROM MOVIES
ORDER BY movieName ASC


--updating stuff
DELETE MOVIES
WHERE movieID = 4;

UPDATE MOVIES
SET movieName = 'Top Gun'
WHERE userID = 3;

SELECT (movieID) AS 'Movie ID',(userID) AS 'User ID',(movieName) AS 'Name',(movieDirector) AS 'Director',
	   (movieGenre) AS 'Genre',(movieLength) AS 'Length'
FROM MOVIES

--only get directors
SELECT movies.movieDirector
FROM MOVIES
ORDER BY movieDirector ASC

--longest v shortest movie
SELECT movies.movieLength
FROM MOVIES
ORDER BY movieLength ASC

SELECT

--"SELECT TOP (1000) [movieID],[userID],
  --                                      [movieName],[movieDirector],
    --                                    [movieGenre],[movieLength]


