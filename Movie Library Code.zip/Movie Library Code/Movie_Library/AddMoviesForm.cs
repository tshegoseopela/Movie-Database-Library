﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_Library
{
    public partial class AddMoviesForm : Form
    {
        public AddMoviesForm()
        {
            InitializeComponent();
        }

        //SQL Connectiong to Movie_DB_Library Database
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-T46RO6F4;Initial Catalog=MOVIE_DB_LIBRARY;Integrated Security=True");

        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            try
            {
                //variables linked to input controls + enabling user input
                int mID = int.Parse(txtmID.Text);
                int uID = int.Parse(txtUserID.Text);
                string mName = txtName.Text;
                string mDirector = txtDirector.Text;
                string mGenre = txtGenre.Text;
                int mLength = int.Parse(txtLength.Text);

                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO MOVIES(movieID,userID,movieName,movieDirector,movieGenre,movieLength)VALUES('" + mID + "','" + uID + "','" + mName + "','" + mDirector + "','" + mGenre + "','" + mLength + "')",conn);

                int i = cmd.ExecuteNonQuery();
                if (i! == 0)
                {
                    MessageBox.Show("Error");
                }
                else
                {
                    MessageBox.Show("New Movie added to DB");
                }
                conn.Close();
            }
            catch(IOException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnHomeBack_Click(object sender, EventArgs e)
        {
            MenuForm mf = new MenuForm();
            this.Hide();
            mf.ShowDialog();
        }

        private void btnViewMovies_Click(object sender, EventArgs e)
        {
            ViewMoviesForm vm = new ViewMoviesForm();
            this.Hide();
            vm.ShowDialog();
        }
    }
}
