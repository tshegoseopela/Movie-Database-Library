﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Library
{
    public partial class ViewMoviesForm : Form
    {

        //SQL Connection
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-T46RO6F4;Initial Catalog=MOVIE_DB_LIBRARY;Integrated Security=True");

        public ViewMoviesForm()
        {
            InitializeComponent();
            cmbDirector.Hide();
            cmbLength.Hide();
            cmbGenre.Hide();


            //SqlCommand cmd = new SqlCommand();
            //cmd.CommandText = "SELECT movies.movieDirector FROM MOVIES ORDER BY movieDirector ASC";
            conn.Open();
            SqlDataAdapter adapter = new SqlDataAdapter("SELECT movies.movieDirector FROM MOVIES ORDER BY movieDirector ASC",conn);
            DataTable dtbl = new DataTable();
            adapter.Fill(dtbl);
            cmbDirector.DataSource = dtbl;
            conn.Close();

        }

       

        private void btnViewAll_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlDataAdapter sqlDA = new SqlDataAdapter(@"SELECT(movieID) AS 'Movie ID', 
                                        (userID) AS 'User ID', (movieName) AS 'Name', 
                                        (movieDirector) AS 'Director',(movieGenre) AS 'Genre', 
                                        (movieLength) AS 'Length'
                                        FROM[MOVIE_DB_LIBRARY].[dbo].[MOVIES]", conn);
                DataTable dtbl = new DataTable();
                sqlDA.Fill(dtbl);
                dgMovies.DataSource = dtbl;
                conn.Close();
            }catch(IOException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnFilter_Click(object sender, EventArgs e)
        {
            if (cmbLength.SelectedIndex == 0)
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter(@"SELECT * FROM MOVIES ORDER BY movieLength DESC", conn);
                    DataTable dtbl = new DataTable();
                    sqlData.Fill(dtbl);
                    dgMovies.DataSource = dtbl;
                    conn.Close();
                }catch (Exception ex){
                    MessageBox.Show(ex.Message);
                }
            }else if (cmbLength.SelectedIndex == 1){
                try
                {
                    conn.Open();
                    SqlDataAdapter sqlData = new SqlDataAdapter(@"SELECT * FROM MOVIES ORDER BY movieLength ASC", conn);
                    DataTable dtbl = new DataTable();
                    sqlData.Fill(dtbl);
                    dgMovies.DataSource = dtbl;
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void radLength_CheckedChanged(object sender, EventArgs e)
        {
            if (radLength.Checked)
            {
                cmbLength.Show();
                cmbGenre.Hide();
                cmbDirector.Hide();
            }
        }

        private void radDirector_CheckedChanged(object sender, EventArgs e)
        {
            if (radDirector.Checked)
            {
                cmbDirector.Show();
                cmbGenre.Hide();
                cmbLength.Hide();
            }
        }

        private void radGenre_CheckedChanged(object sender, EventArgs e)
        {
            if (radGenre.Checked)
            {
                cmbGenre.Show();
                cmbDirector.Hide();
                cmbLength.Hide();
            }
        }
    }
}
