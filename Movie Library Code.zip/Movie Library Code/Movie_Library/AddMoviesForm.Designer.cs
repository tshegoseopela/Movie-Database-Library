﻿namespace Movie_Library
{
    partial class AddMoviesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblHeading = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            this.lblDirector = new System.Windows.Forms.Label();
            this.lblGenre = new System.Windows.Forms.Label();
            this.lblLength = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtDirector = new System.Windows.Forms.TextBox();
            this.txtGenre = new System.Windows.Forms.TextBox();
            this.txtLength = new System.Windows.Forms.TextBox();
            this.btnAddMovie = new System.Windows.Forms.Button();
            this.lblMovieID = new System.Windows.Forms.Label();
            this.txtmID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtUserID = new System.Windows.Forms.TextBox();
            this.btnHomeBack = new System.Windows.Forms.Button();
            this.btnViewMovies = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblHeading
            // 
            this.lblHeading.AutoSize = true;
            this.lblHeading.Location = new System.Drawing.Point(373, 24);
            this.lblHeading.Name = "lblHeading";
            this.lblHeading.Size = new System.Drawing.Size(140, 25);
            this.lblHeading.TabIndex = 0;
            this.lblHeading.Text = "Add New Movie";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(56, 205);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(158, 25);
            this.lblName.TabIndex = 1;
            this.lblName.Text = "Enter Movie Name";
            // 
            // lblDirector
            // 
            this.lblDirector.AutoSize = true;
            this.lblDirector.Location = new System.Drawing.Point(56, 260);
            this.lblDirector.Name = "lblDirector";
            this.lblDirector.Size = new System.Drawing.Size(120, 25);
            this.lblDirector.TabIndex = 2;
            this.lblDirector.Text = "Enter Director";
            // 
            // lblGenre
            // 
            this.lblGenre.AutoSize = true;
            this.lblGenre.Location = new System.Drawing.Point(56, 313);
            this.lblGenre.Name = "lblGenre";
            this.lblGenre.Size = new System.Drawing.Size(103, 25);
            this.lblGenre.TabIndex = 3;
            this.lblGenre.Text = "Enter Genre";
            // 
            // lblLength
            // 
            this.lblLength.AutoSize = true;
            this.lblLength.Location = new System.Drawing.Point(56, 374);
            this.lblLength.Name = "lblLength";
            this.lblLength.Size = new System.Drawing.Size(111, 25);
            this.lblLength.TabIndex = 4;
            this.lblLength.Text = "Enter Length";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(261, 202);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(273, 31);
            this.txtName.TabIndex = 5;
            // 
            // txtDirector
            // 
            this.txtDirector.Location = new System.Drawing.Point(261, 260);
            this.txtDirector.Name = "txtDirector";
            this.txtDirector.Size = new System.Drawing.Size(273, 31);
            this.txtDirector.TabIndex = 6;
            // 
            // txtGenre
            // 
            this.txtGenre.Location = new System.Drawing.Point(261, 318);
            this.txtGenre.Name = "txtGenre";
            this.txtGenre.Size = new System.Drawing.Size(273, 31);
            this.txtGenre.TabIndex = 7;
            // 
            // txtLength
            // 
            this.txtLength.Location = new System.Drawing.Point(261, 378);
            this.txtLength.Name = "txtLength";
            this.txtLength.Size = new System.Drawing.Size(273, 31);
            this.txtLength.TabIndex = 8;
            // 
            // btnAddMovie
            // 
            this.btnAddMovie.Location = new System.Drawing.Point(365, 433);
            this.btnAddMovie.Name = "btnAddMovie";
            this.btnAddMovie.Size = new System.Drawing.Size(165, 45);
            this.btnAddMovie.TabIndex = 9;
            this.btnAddMovie.Text = "Add Movie";
            this.btnAddMovie.UseVisualStyleBackColor = true;
            this.btnAddMovie.Click += new System.EventHandler(this.btnAddMovie_Click);
            // 
            // lblMovieID
            // 
            this.lblMovieID.AutoSize = true;
            this.lblMovieID.Location = new System.Drawing.Point(56, 91);
            this.lblMovieID.Name = "lblMovieID";
            this.lblMovieID.Size = new System.Drawing.Size(129, 25);
            this.lblMovieID.TabIndex = 10;
            this.lblMovieID.Text = "Enter Movie ID";
            // 
            // txtmID
            // 
            this.txtmID.Location = new System.Drawing.Point(261, 91);
            this.txtmID.Name = "txtmID";
            this.txtmID.Size = new System.Drawing.Size(273, 31);
            this.txtmID.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 25);
            this.label1.TabIndex = 12;
            this.label1.Text = "Enter User ID";
            // 
            // txtUserID
            // 
            this.txtUserID.Location = new System.Drawing.Point(261, 156);
            this.txtUserID.Name = "txtUserID";
            this.txtUserID.Size = new System.Drawing.Size(273, 31);
            this.txtUserID.TabIndex = 13;
            // 
            // btnHomeBack
            // 
            this.btnHomeBack.Location = new System.Drawing.Point(577, 506);
            this.btnHomeBack.Name = "btnHomeBack";
            this.btnHomeBack.Size = new System.Drawing.Size(152, 46);
            this.btnHomeBack.TabIndex = 14;
            this.btnHomeBack.Text = "Home";
            this.btnHomeBack.UseVisualStyleBackColor = true;
            this.btnHomeBack.Click += new System.EventHandler(this.btnHomeBack_Click);
            // 
            // btnViewMovies
            // 
            this.btnViewMovies.Location = new System.Drawing.Point(747, 506);
            this.btnViewMovies.Name = "btnViewMovies";
            this.btnViewMovies.Size = new System.Drawing.Size(153, 46);
            this.btnViewMovies.TabIndex = 15;
            this.btnViewMovies.Text = "View All Movies";
            this.btnViewMovies.UseVisualStyleBackColor = true;
            this.btnViewMovies.Click += new System.EventHandler(this.btnViewMovies_Click);
            // 
            // AddMoviesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(942, 583);
            this.Controls.Add(this.btnViewMovies);
            this.Controls.Add(this.btnHomeBack);
            this.Controls.Add(this.txtUserID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtmID);
            this.Controls.Add(this.lblMovieID);
            this.Controls.Add(this.btnAddMovie);
            this.Controls.Add(this.txtLength);
            this.Controls.Add(this.txtGenre);
            this.Controls.Add(this.txtDirector);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblLength);
            this.Controls.Add(this.lblGenre);
            this.Controls.Add(this.lblDirector);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.lblHeading);
            this.Name = "AddMoviesForm";
            this.Text = "AddMoviesForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblHeading;
        private Label lblName;
        private Label lblDirector;
        private Label lblGenre;
        private Label lblLength;
        private TextBox txtName;
        private TextBox txtDirector;
        private TextBox txtGenre;
        private TextBox txtLength;
        private Button btnAddMovie;
        private Label lblMovieID;
        private TextBox txtmID;
        private Label label1;
        private TextBox txtUserID;
        private Button btnHomeBack;
        private Button btnViewMovies;
    }
}