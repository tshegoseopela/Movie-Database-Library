﻿namespace Movie_Library
{
    partial class ViewMoviesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblView = new System.Windows.Forms.Label();
            this.lblViewAll = new System.Windows.Forms.Label();
            this.btnViewAll = new System.Windows.Forms.Button();
            this.lblFilter = new System.Windows.Forms.Label();
            this.radLength = new System.Windows.Forms.RadioButton();
            this.radDirector = new System.Windows.Forms.RadioButton();
            this.radGenre = new System.Windows.Forms.RadioButton();
            this.cmbLength = new System.Windows.Forms.ComboBox();
            this.cmbDirector = new System.Windows.Forms.ComboBox();
            this.cmbGenre = new System.Windows.Forms.ComboBox();
            this.btnFilter = new System.Windows.Forms.Button();
            this.dgMovies = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgMovies)).BeginInit();
            this.SuspendLayout();
            // 
            // lblView
            // 
            this.lblView.AutoSize = true;
            this.lblView.Location = new System.Drawing.Point(288, 26);
            this.lblView.Name = "lblView";
            this.lblView.Size = new System.Drawing.Size(171, 25);
            this.lblView.TabIndex = 0;
            this.lblView.Text = "View Movie Records";
            // 
            // lblViewAll
            // 
            this.lblViewAll.AutoSize = true;
            this.lblViewAll.Location = new System.Drawing.Point(77, 85);
            this.lblViewAll.Name = "lblViewAll";
            this.lblViewAll.Size = new System.Drawing.Size(142, 25);
            this.lblViewAll.TabIndex = 1;
            this.lblViewAll.Text = "View All Records";
            // 
            // btnViewAll
            // 
            this.btnViewAll.Location = new System.Drawing.Point(77, 113);
            this.btnViewAll.Name = "btnViewAll";
            this.btnViewAll.Size = new System.Drawing.Size(168, 39);
            this.btnViewAll.TabIndex = 2;
            this.btnViewAll.Text = "View All Records";
            this.btnViewAll.UseVisualStyleBackColor = true;
            this.btnViewAll.Click += new System.EventHandler(this.btnViewAll_Click);
            // 
            // lblFilter
            // 
            this.lblFilter.AutoSize = true;
            this.lblFilter.Location = new System.Drawing.Point(403, 76);
            this.lblFilter.Name = "lblFilter";
            this.lblFilter.Size = new System.Drawing.Size(78, 25);
            this.lblFilter.TabIndex = 3;
            this.lblFilter.Text = "Filter By:";
            // 
            // radLength
            // 
            this.radLength.AutoSize = true;
            this.radLength.Location = new System.Drawing.Point(403, 118);
            this.radLength.Name = "radLength";
            this.radLength.Size = new System.Drawing.Size(91, 29);
            this.radLength.TabIndex = 4;
            this.radLength.TabStop = true;
            this.radLength.Text = "Length";
            this.radLength.UseVisualStyleBackColor = true;
            this.radLength.CheckedChanged += new System.EventHandler(this.radLength_CheckedChanged);
            // 
            // radDirector
            // 
            this.radDirector.AutoSize = true;
            this.radDirector.Location = new System.Drawing.Point(403, 167);
            this.radDirector.Name = "radDirector";
            this.radDirector.Size = new System.Drawing.Size(100, 29);
            this.radDirector.TabIndex = 5;
            this.radDirector.TabStop = true;
            this.radDirector.Text = "Director";
            this.radDirector.UseVisualStyleBackColor = true;
            this.radDirector.CheckedChanged += new System.EventHandler(this.radDirector_CheckedChanged);
            // 
            // radGenre
            // 
            this.radGenre.AutoSize = true;
            this.radGenre.Location = new System.Drawing.Point(403, 213);
            this.radGenre.Name = "radGenre";
            this.radGenre.Size = new System.Drawing.Size(83, 29);
            this.radGenre.TabIndex = 6;
            this.radGenre.TabStop = true;
            this.radGenre.Text = "Genre";
            this.radGenre.UseVisualStyleBackColor = true;
            this.radGenre.CheckedChanged += new System.EventHandler(this.radGenre_CheckedChanged);
            // 
            // cmbLength
            // 
            this.cmbLength.FormattingEnabled = true;
            this.cmbLength.Items.AddRange(new object[] {
            "Longest",
            "Shortest"});
            this.cmbLength.Location = new System.Drawing.Point(548, 119);
            this.cmbLength.Name = "cmbLength";
            this.cmbLength.Size = new System.Drawing.Size(182, 33);
            this.cmbLength.TabIndex = 7;
            // 
            // cmbDirector
            // 
            this.cmbDirector.FormattingEnabled = true;
            this.cmbDirector.Location = new System.Drawing.Point(548, 167);
            this.cmbDirector.Name = "cmbDirector";
            this.cmbDirector.Size = new System.Drawing.Size(182, 33);
            this.cmbDirector.TabIndex = 8;
            // 
            // cmbGenre
            // 
            this.cmbGenre.FormattingEnabled = true;
            this.cmbGenre.Location = new System.Drawing.Point(548, 213);
            this.cmbGenre.Name = "cmbGenre";
            this.cmbGenre.Size = new System.Drawing.Size(182, 33);
            this.cmbGenre.TabIndex = 9;
            // 
            // btnFilter
            // 
            this.btnFilter.Location = new System.Drawing.Point(548, 271);
            this.btnFilter.Name = "btnFilter";
            this.btnFilter.Size = new System.Drawing.Size(112, 34);
            this.btnFilter.TabIndex = 10;
            this.btnFilter.Text = "Filter";
            this.btnFilter.UseVisualStyleBackColor = true;
            this.btnFilter.Click += new System.EventHandler(this.btnFilter_Click);
            // 
            // dgMovies
            // 
            this.dgMovies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgMovies.Location = new System.Drawing.Point(77, 359);
            this.dgMovies.Name = "dgMovies";
            this.dgMovies.RowHeadersWidth = 62;
            this.dgMovies.RowTemplate.Height = 33;
            this.dgMovies.Size = new System.Drawing.Size(746, 274);
            this.dgMovies.TabIndex = 11;
            // 
            // ViewMoviesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 666);
            this.Controls.Add(this.dgMovies);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.cmbGenre);
            this.Controls.Add(this.cmbDirector);
            this.Controls.Add(this.cmbLength);
            this.Controls.Add(this.radGenre);
            this.Controls.Add(this.radDirector);
            this.Controls.Add(this.radLength);
            this.Controls.Add(this.lblFilter);
            this.Controls.Add(this.btnViewAll);
            this.Controls.Add(this.lblViewAll);
            this.Controls.Add(this.lblView);
            this.Name = "ViewMoviesForm";
            this.Text = "View Movies ";
            ((System.ComponentModel.ISupportInitialize)(this.dgMovies)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblView;
        private Label lblViewAll;
        private Button btnViewAll;
        private Label lblFilter;
        private RadioButton radLength;
        private RadioButton radDirector;
        private RadioButton radGenre;
        private ComboBox cmbLength;
        private ComboBox cmbDirector;
        private ComboBox cmbGenre;
        private Button btnFilter;
        private DataGridView dgMovies;
    }
}