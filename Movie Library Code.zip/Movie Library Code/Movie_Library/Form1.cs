namespace Movie_Library
{
    public partial class MenuForm : Form
    {
        public MenuForm()
        {
            InitializeComponent();
        }

        private void btnAddMovie_Click(object sender, EventArgs e)
        {
            AddMoviesForm am = new AddMoviesForm();
            this.Hide();
            am.ShowDialog();
        }

        private void btnViewMovies_Click(object sender, EventArgs e)
        {
            ViewMoviesForm vm = new ViewMoviesForm();
            this.Hide();
            vm.ShowDialog();
        }
    }
}